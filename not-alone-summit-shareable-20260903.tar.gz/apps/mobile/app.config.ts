import type { ExpoConfig } from "expo/config";
import { publicAppConfig } from "@not-alone/config";

const config: ExpoConfig = {
  name: publicAppConfig.appName,
  slug: publicAppConfig.appSlug,
  scheme: "notalone",
  version: "0.1.0",
  orientation: "portrait",
  userInterfaceStyle: "automatic",
  icon: "./assets/icon.png",
  ios: {
    supportsTablet: false,
    bundleIdentifier: publicAppConfig.iosBundleIdentifier,
    infoPlist: {
      NSUserNotificationsUsageDescription:
        "Notifications provide schedule reminders and urgent event changes for Not Alone Summit."
    }
  },
  updates: {
    url: "https://u.expo.dev/replace-with-eas-project-id",
    enabled: true,
    checkAutomatically: "ON_LOAD",
    fallbackToCacheTimeout: 0
  },
  runtimeVersion: "0.1.0",
  extra: {
    eas: {
      projectId: "replace-with-eas-project-id"
    },
    appEnv: publicAppConfig.environmentName,
    eventId: publicAppConfig.eventId,
    apiBaseUrl: publicAppConfig.apiBaseUrl
  },
  plugins: [
    "expo-router",
    "expo-secure-store",
    "expo-sqlite",
    "expo-notifications",
    "expo-updates",
    [
      "expo-splash-screen",
      {
        image: "./assets/splash.png",
        resizeMode: "contain",
        backgroundColor: "#F7F5F0"
      }
    ]
  ]
};

export default config;
