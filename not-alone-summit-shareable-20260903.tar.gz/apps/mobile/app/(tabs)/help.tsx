import { Link } from "expo-router";
import { useState } from "react";
import { ImageBackground, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors, spacing, typography } from "@not-alone/design-tokens";
import { getNowAndUpcoming, toEventTimeRange } from "@not-alone/domain";
import { useSummitDemo } from "../../components/demo-mode";

const summitArt = require("../../assets/summit-art-v2.png");

const promptChips = [
  "What is happening now?",
  "Where do I go next?",
  "What can I attend tonight?",
  "Where can I take a quiet break?"
];

export default function HelpScreen() {
  const [selectedPrompt, setSelectedPrompt] = useState<string>(promptChips[0] ?? "What is happening now?");
  const { demoEnabled, snapshot, nowUtc, setDemoEnabled } = useSummitDemo();
  const { current, upcoming } = getNowAndUpcoming({
    audienceGroups: ["founders"],
    nowUtc,
    snapshot
  });
  const currentItem = current[0];
  const nextItem = upcoming[0];

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <ScrollView
        style={styles.screen}
        contentContainerStyle={styles.content}
        contentInsetAdjustmentBehavior="automatic"
      >
        <ImageBackground source={summitArt} resizeMode="cover" imageStyle={styles.heroImage} style={styles.hero}>
          <View style={styles.heroScrim}>
            <Text style={styles.kicker}>Ask AI</Text>
            <Text style={styles.title}>Your summit concierge.</Text>
            <Text style={styles.copy}>
              Calm answers for schedule, rooms, support, and what to do next.
            </Text>
          </View>
        </ImageBackground>

        <View style={styles.promptPanel}>
          <Text style={styles.promptTitle}>How can I help today?</Text>
          <View style={styles.chipGrid}>
            {promptChips.map((prompt) => (
              <Pressable
                key={prompt}
                onPress={() => setSelectedPrompt(prompt)}
                style={({ pressed }) => [
                  styles.promptChip,
                  selectedPrompt === prompt && styles.promptChipActive,
                  pressed && styles.pressed
                ]}
              >
                <Text style={[styles.promptChipText, selectedPrompt === prompt && styles.promptChipTextActive]}>{prompt}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.inputShell}>
            <Text style={styles.inputText}>Ask anything...</Text>
            <View style={styles.sendButton}>
              <Text style={styles.sendText}>Send</Text>
            </View>
          </View>
        </View>

        <View style={styles.answerPanel}>
          <Text style={styles.answerKicker}>{demoEnabled ? "Demo answer" : "Coming soon"}</Text>
          {demoEnabled && currentItem ? (
            <>
              <Text style={styles.answerTitle}>{getDemoAnswerTitle(selectedPrompt, currentItem.locationName)}</Text>
              <Text style={styles.answerBody}>
                {getDemoAnswerBody({ selectedPrompt, currentTitle: currentItem.title, currentTime: toEventTimeRange(currentItem, snapshot.event.timeZone), nextTitle: nextItem?.title, nextTime: nextItem ? toEventTimeRange(nextItem, snapshot.event.timeZone).split(" - ")[0] : undefined })}
              </Text>
            </>
          ) : (
            <>
              <Text style={styles.answerTitle}>Concierge preview is ready.</Text>
              <Text style={styles.answerBody}>
                Turn on temporary Demo Mode to see how the assistant will answer against live agenda and venue data.
              </Text>
              <Pressable onPress={() => setDemoEnabled(true)} style={({ pressed }) => [styles.previewButton, pressed && styles.pressed]}>
                <Text style={styles.previewButtonText}>Preview Demo Mode</Text>
              </Pressable>
            </>
          )}
        </View>

        <View style={styles.panel}>
          <CapabilityRow title="Schedule answers" body="Grounded in the same published agenda used by Home and Schedule." />
          <CapabilityRow title="Venue guidance" body="Designed to answer from approved room, map, and accessibility records." />
          <CapabilityRow title="Human support" body="Sensitive or unresolved requests should route to a trained event team member." />
        </View>

        <Link href="/schedule" asChild>
          <Pressable style={({ pressed }) => [styles.scheduleLink, pressed && styles.pressed]}>
            <Text style={styles.scheduleLinkText}>Open Full Schedule</Text>
          </Pressable>
        </Link>
      </ScrollView>
    </SafeAreaView>
  );
}

function getDemoAnswerTitle(prompt: string, locationName: string) {
  if (prompt.includes("quiet")) {
    return "Reflection Lounge is the calmest next stop.";
  }

  if (prompt.includes("Where")) {
    return `Head to ${locationName}.`;
  }

  if (prompt.includes("tonight")) {
    return "Your evening options are queued.";
  }

  return "Here is what matters right now.";
}

function getDemoAnswerBody({
  selectedPrompt,
  currentTitle,
  currentTime,
  nextTitle,
  nextTime
}: {
  selectedPrompt: string;
  currentTitle: string;
  currentTime: string;
  nextTitle: string | undefined;
  nextTime: string | undefined;
}) {
  if (selectedPrompt.includes("quiet")) {
    return "Use the demo map to find the Reflection Lounge between sessions. In the real app, this will come from approved venue records.";
  }

  if (selectedPrompt.includes("tonight")) {
    return "Demo Mode includes an invite-only reception later today so we can preview access labels, reminders, and private-event handling.";
  }

  if (selectedPrompt.includes("Where")) {
    return `${currentTitle} is live from ${currentTime}. ${nextTitle && nextTime ? `After that, ${nextTitle} begins at ${nextTime}.` : ""}`;
  }

  return `${currentTitle} is live from ${currentTime}. ${nextTitle && nextTime ? `Next: ${nextTitle} at ${nextTime}.` : ""}`;
}

function CapabilityRow({ title, body }: { title: string; body: string }) {
  return (
    <View style={styles.helpRow}>
      <Text style={styles.helpTitle}>{title}</Text>
      <Text style={styles.helpBody}>{body}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: colors.canvas,
    flex: 1
  },
  screen: {
    backgroundColor: colors.canvas
  },
  content: {
    paddingBottom: 116
  },
  hero: {
    backgroundColor: colors.midnight,
    borderColor: "rgba(230, 192, 111, 0.18)",
    borderRadius: 8,
    borderWidth: 1,
    marginHorizontal: spacing.lg,
    marginTop: spacing.lg,
    minHeight: 220,
    overflow: "hidden"
  },
  heroImage: {
    borderRadius: 8
  },
  heroScrim: {
    backgroundColor: "rgba(5, 10, 30, 0.62)",
    flex: 1,
    justifyContent: "flex-end",
    padding: spacing.lg
  },
  kicker: {
    color: colors.gold,
    fontFamily: typography.bold,
    fontSize: 12,
    fontWeight: "700",
    textTransform: "uppercase"
  },
  title: {
    color: colors.ink,
    fontFamily: typography.display,
    fontSize: 39,
    fontWeight: "700",
    letterSpacing: 0,
    lineHeight: 43,
    marginTop: spacing.xs
  },
  copy: {
    color: colors.surfaceMuted,
    fontSize: 16,
    lineHeight: 23,
    marginTop: spacing.md
  },
  promptPanel: {
    backgroundColor: "#0D1530",
    borderColor: colors.border,
    borderRadius: 8,
    borderWidth: 1,
    marginHorizontal: spacing.lg,
    marginTop: spacing.lg,
    padding: spacing.lg
  },
  promptTitle: {
    color: colors.ink,
    fontFamily: typography.display,
    fontSize: 28,
    fontWeight: "700",
    letterSpacing: 0
  },
  chipGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
    marginTop: spacing.lg
  },
  promptChip: {
    backgroundColor: "rgba(255, 255, 255, 0.06)",
    borderColor: "rgba(230, 192, 111, 0.18)",
    borderRadius: 8,
    borderWidth: 1,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md
  },
  promptChipActive: {
    backgroundColor: colors.gold
  },
  promptChipText: {
    color: colors.surfaceMuted,
    fontFamily: typography.medium,
    fontSize: 14,
    fontWeight: "500"
  },
  promptChipTextActive: {
    color: colors.midnight,
    fontFamily: typography.bold,
    fontWeight: "800"
  },
  inputShell: {
    alignItems: "center",
    backgroundColor: "rgba(5, 10, 30, 0.82)",
    borderColor: colors.border,
    borderRadius: 8,
    borderWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: spacing.lg,
    paddingLeft: spacing.md,
    paddingVertical: spacing.sm
  },
  inputText: {
    color: colors.muted,
    fontSize: 14
  },
  sendButton: {
    backgroundColor: colors.gold,
    borderRadius: 8,
    marginRight: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm
  },
  sendText: {
    color: colors.midnight,
    fontFamily: typography.bold,
    fontSize: 12,
    fontWeight: "800"
  },
  answerPanel: {
    backgroundColor: "rgba(13, 21, 48, 0.78)",
    borderColor: "rgba(230, 192, 111, 0.22)",
    borderRadius: 8,
    borderWidth: 1,
    marginHorizontal: spacing.lg,
    marginTop: spacing.lg,
    padding: spacing.lg
  },
  answerKicker: {
    color: colors.gold,
    fontFamily: typography.bold,
    fontSize: 11,
    fontWeight: "700",
    textTransform: "uppercase"
  },
  answerTitle: {
    color: colors.ink,
    fontFamily: typography.bold,
    fontSize: 22,
    fontWeight: "700",
    lineHeight: 27,
    marginTop: spacing.xs
  },
  answerBody: {
    color: colors.body,
    fontSize: 15,
    lineHeight: 23,
    marginTop: spacing.sm
  },
  previewButton: {
    alignSelf: "flex-start",
    backgroundColor: colors.gold,
    borderRadius: 8,
    marginTop: spacing.lg,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md
  },
  previewButtonText: {
    color: colors.midnight,
    fontFamily: typography.bold,
    fontSize: 13,
    fontWeight: "800"
  },
  panel: {
    backgroundColor: "rgba(13, 21, 48, 0.72)",
    borderColor: colors.border,
    borderRadius: 8,
    borderWidth: 1,
    marginHorizontal: spacing.lg,
    marginTop: spacing.lg
  },
  helpRow: {
    borderTopColor: colors.border,
    borderTopWidth: 1,
    padding: spacing.lg
  },
  helpTitle: {
    color: colors.ink,
    fontFamily: typography.bold,
    fontSize: 18,
    fontWeight: "700"
  },
  helpBody: {
    color: colors.body,
    fontSize: 14,
    lineHeight: 21,
    marginTop: spacing.xs
  },
  scheduleLink: {
    alignItems: "center",
    borderColor: colors.gold,
    borderRadius: 8,
    borderWidth: 1,
    marginHorizontal: spacing.lg,
    marginTop: spacing.lg,
    paddingVertical: spacing.md
  },
  scheduleLinkText: {
    color: colors.gold,
    fontFamily: typography.bold,
    fontSize: 13,
    fontWeight: "800",
    textTransform: "uppercase"
  },
  pressed: {
    opacity: 0.84
  }
});
