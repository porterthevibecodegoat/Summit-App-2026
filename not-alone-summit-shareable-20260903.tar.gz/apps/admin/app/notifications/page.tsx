import Link from "next/link";
import { publicAppConfig } from "@not-alone/config";
import { getLiveOpsState } from "../../lib/live-ops-repository";

export const dynamic = "force-dynamic";

export default async function NotificationsPage() {
  const state = await getLiveOpsState();
  const scheduledJobs = state.notificationJobs.filter((job) => job.status === "scheduled");

  return (
    <main className="shell">
      <nav className="nav" aria-label="Staff portal">
        <div className="brand">{publicAppConfig.appName}</div>
        <Link href="/">Overview</Link>
        <Link href="/schedule">Schedule</Link>
        <span>Ask AI</span>
        <span>Make Changes</span>
        <span>Import</span>
        <Link className="active" href="/notifications">Notifications</Link>
        <span>Emergency</span>
        <Link href="/history">History</Link>
        <span>Settings</span>
      </nav>
      <section className="content">
        <div className="pageHeader">
          <div>
            <div className="kicker">Notification Operations · Local adapter</div>
            <h1>Reminder queue</h1>
            <p className="headerCopy">
              Publishing a schedule revision recalculates reminder jobs here. Delivery stays disabled until Expo/APNs
              credentials and a server worker are authorized.
            </p>
          </div>
          <div className="environmentBadge">{publicAppConfig.environmentName}</div>
        </div>

        <div className="metricGrid">
          <div className="metric">
            <div className="label">Published revision</div>
            <div className="value">{state.publishedSnapshot.revision}</div>
          </div>
          <div className="metric">
            <div className="label">Scheduled jobs</div>
            <div className="value">{scheduledJobs.length}</div>
          </div>
          <div className="metric">
            <div className="label">Registered devices</div>
            <div className="value">{state.attendeeDevices}</div>
          </div>
          <div className="metric">
            <div className="label">Push delivery</div>
            <div className="value">Off</div>
          </div>
        </div>

        <div className="systemNotice">
          Current backend mode: {state.mode}. Reminder metadata is prepared, but nothing is sent to attendee phones yet.
          The production step is to connect Expo push credentials and an audited dispatch worker.
        </div>

        <section className="panel">
          <div className="panelHeader">
            <div>
              <div className="label">Queued reminder metadata</div>
              <h2>Jobs created from the published schedule</h2>
            </div>
            <Link className="textButton" href="/schedule">Manage schedule</Link>
          </div>
          <div className="timeline">
            {scheduledJobs.length === 0 ? (
              <div className="row">
                <div className="time">No jobs</div>
                <div>
                  <div className="title">No reminders are queued yet.</div>
                  <div className="summary">Publish a ready schedule revision to generate reminder jobs.</div>
                </div>
                <div className="badge">Waiting</div>
              </div>
            ) : (
              scheduledJobs.map((job) => (
                <div className="row" key={job.id}>
                  <div className="time">{new Date(job.sendAfterUtc).toLocaleString()}</div>
                  <div>
                    <div className="title">{job.audienceScope}</div>
                    <div className="summary">Schedule item {job.scheduleItemId}</div>
                  </div>
                  <div className="badge">{job.status}</div>
                </div>
              ))
            )}
          </div>
        </section>
      </section>
    </main>
  );
}
