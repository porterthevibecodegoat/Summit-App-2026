import type { ReactNode } from "react";
import "./styles.css";

export const metadata = {
  title: "Not Alone Summit Staff Portal",
  description: "Staff Event Control Portal for Not Alone Summit"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
