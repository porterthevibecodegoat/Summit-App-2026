import Link from "next/link";
import { publicAppConfig } from "@not-alone/config";
import { getNowAndUpcoming, toEventTimeRange } from "@not-alone/domain";
import { getLiveOpsState } from "../lib/live-ops-repository";

export const dynamic = "force-dynamic";

export default async function LiveOperationsPage() {
  const state = await getLiveOpsState();
  const snapshot = state.publishedSnapshot;
  const timeline = getNowAndUpcoming({
    snapshot,
    nowUtc: "2026-11-02T18:30:00.000Z",
    audienceGroups: ["all_attendees", "founders"]
  });
  const visibleTimeline = [...timeline.current, ...timeline.upcoming];
  const draftNeedsReview = state.draftSessions.filter((session) => session.status === "Needs review").length;
  const draftReady = state.draftSessions.filter((session) => session.status === "Ready").length;

  return (
    <main className="shell">
      <nav className="nav" aria-label="Staff portal">
        <div className="brand">{publicAppConfig.appName}</div>
        <Link className="active" href="/">Overview</Link>
        <Link href="/schedule">Schedule</Link>
        <span>Ask AI</span>
        <span>Make Changes</span>
        <span>Import</span>
        <Link href="/notifications">Notifications</Link>
        <span>Emergency</span>
        <Link href="/history">History</Link>
        <span>Settings</span>
      </nav>
      <section className="content">
        <div className="pageHeader">
          <div>
            <div className="kicker">Staff Event Control Portal · Local live adapter</div>
            <h1>{snapshot.event.name}</h1>
            <p className="headerCopy">
              {snapshot.event.dateLabel} · {snapshot.event.venueName} · {snapshot.event.city}
            </p>
          </div>
          <div className="environmentBadge">{publicAppConfig.environmentName}</div>
        </div>

        <div className="metricGrid">
          <div className="metric">
            <div className="label">Draft ready</div>
            <div className="value">{draftReady}</div>
          </div>
          <div className="metric">
            <div className="label">Needs review</div>
            <div className="value">{draftNeedsReview}</div>
          </div>
          <div className="metric">
            <div className="label">Notification jobs</div>
            <div className="value">{state.notificationJobs.length}</div>
          </div>
          <div className="metric">
            <div className="label">Content revision</div>
            <div className="value">{snapshot.revision}</div>
          </div>
        </div>

        <div className="quickActionGrid">
          <Link className="quickAction" href="/schedule">
            <span>Schedule workbench</span>
            <strong>Edit, review, publish</strong>
          </Link>
          <Link className="quickAction" href="/notifications">
            <span>Notifications</span>
            <strong>Review queued jobs</strong>
          </Link>
          <Link className="quickAction" href="/history">
            <span>History</span>
            <strong>See recent changes</strong>
          </Link>
        </div>

        <div className="systemNotice">
          Backend mode: {state.mode}. Drafts, published snapshot, notification jobs, and mobile sync all read through
          the same live-ops adapter.
        </div>

        <div className="panel">
          <div className="panelHeader">
            <div>
              <div className="label">Now and Next</div>
              <h2>Attendee-facing timeline</h2>
            </div>
            <Link className="textButton" href="/schedule">Manage schedule</Link>
          </div>
          <div className="timeline">
            {visibleTimeline.length === 0 ? (
              <div className="row">
                <div className="time">No live items</div>
                <div>
                  <div className="title">No attendee schedule has been published yet.</div>
                  <div className="summary">
                    The shared event model is ready for approved agenda records, locations, visibility rules, and
                    notification metadata.
                  </div>
                </div>
                <div className="badge">Ready</div>
              </div>
            ) : (
              visibleTimeline.map((item) => (
                <div className="row" key={item.id}>
                  <div className="time">{toEventTimeRange(item, snapshot.event.timeZone)}</div>
                  <div>
                    <div className="title">{item.title}</div>
                    <div className="summary">{item.locationName} · {item.summary}</div>
                  </div>
                  <div className="badge">{item.status}</div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="twoColumn">
          <section className="panel">
            <div className="label">Positioning</div>
            <h2>Human development convening</h2>
            <p>
              {snapshot.event.positioning}
            </p>
          </section>
          <section className="panel">
            <div className="label">Brand context</div>
            <h2>Official source captured</h2>
            <p>
              Presented by {snapshot.event.presentedBy} and powered by {snapshot.event.poweredBy}. Final
              agenda details still require staff approval before production publication.
            </p>
          </section>
        </div>

        <section className="panel">
          <div className="panelHeader">
            <div>
              <div className="label">Recent operations</div>
              <h2>Latest changes</h2>
            </div>
            <Link className="textButton" href="/history">View history</Link>
          </div>
          <div className="timeline">
            {state.activityLog.slice(0, 3).map((entry) => (
              <div className="row" key={entry.id}>
                <div className="time">{new Date(entry.createdAt).toLocaleString()}</div>
                <div>
                  <div className="title">{entry.action}</div>
                  <div className="summary">{entry.detail}</div>
                </div>
                <div className="badge">{entry.actorRole}</div>
              </div>
            ))}
            {state.activityLog.length === 0 ? (
              <div className="row">
                <div className="time">No entries</div>
                <div>
                  <div className="title">No operations have been recorded yet.</div>
                  <div className="summary">Saving or publishing a draft will create audit activity.</div>
                </div>
                <div className="badge">Waiting</div>
              </div>
            ) : null}
          </div>
        </section>
      </section>
    </main>
  );
}
