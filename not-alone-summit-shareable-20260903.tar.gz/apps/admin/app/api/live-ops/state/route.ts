import { NextResponse } from "next/server";
import { getLiveOpsState } from "../../../../lib/live-ops-repository";

export async function GET() {
  const state = await getLiveOpsState();

  return NextResponse.json(
    {
      mode: state.mode,
      eventId: state.eventId,
      revision: state.revision,
      draftSessions: state.draftSessions,
      publishedRevision: state.publishedSnapshot.revision,
      publishedScheduleItems: state.publishedSnapshot.scheduleItems.length,
      lastPublishedAt: state.lastPublishedAt,
      lastPublishedMessage: state.lastPublishedMessage,
      attendeeDevices: state.attendeeDevices,
      notificationJobs: state.notificationJobs,
      notificationJobsCount: state.notificationJobs.length,
      activityLog: state.activityLog
    },
    {
      headers: {
        "Cache-Control": "no-store"
      }
    }
  );
}
