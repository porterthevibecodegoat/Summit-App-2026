import { NextResponse } from "next/server";
import { eventSnapshotSchema } from "@not-alone/validation";
import { getLiveOpsState } from "../../../lib/live-ops-repository";

export async function GET() {
  const state = await getLiveOpsState();
  const snapshot = eventSnapshotSchema.parse({
    ...state.publishedSnapshot,
    serverTimeUtc: new Date().toISOString()
  });

  return NextResponse.json(snapshot, {
    headers: {
      "Cache-Control": "no-store"
    }
  });
}
