import { NextRequest, NextResponse } from "next/server";
import { operatorAiCreateProposal } from "@not-alone/domain";
import { getLiveOpsState } from "../../../../../lib/live-ops-repository";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const commandText = typeof body.commandText === "string" ? body.commandText : "";
  const state = await getLiveOpsState();

  const proposal = operatorAiCreateProposal({
    proposalId: crypto.randomUUID(),
    eventId: state.eventId,
    commandText: commandText || "No command supplied.",
    operations: [],
    createdByRole: "EDITOR",
    createdAt: new Date().toISOString()
  });

  return NextResponse.json(
    {
      aiSystem: "EVENT_OPERATOR_AI",
      productionMutated: false,
      proposal,
      liveOpsState: {
        currentRevision: state.publishedSnapshot.revision,
        draftSessions: state.draftSessions.length,
        notificationJobs: state.notificationJobs.length
      },
      nextRequiredStep: "Human review and explicit publish are required before attendee-facing data can change."
    },
    {
      headers: {
        "Cache-Control": "no-store"
      }
    }
  );
}
