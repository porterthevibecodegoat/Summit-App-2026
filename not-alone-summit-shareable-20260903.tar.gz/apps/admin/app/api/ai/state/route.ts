import { NextRequest, NextResponse } from "next/server";
import { getNowAndUpcoming } from "@not-alone/domain";
import { getLiveOpsState } from "../../../../lib/live-ops-repository";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const question = typeof body.question === "string" ? body.question : "What is the current event state?";
  const state = await getLiveOpsState();
  const snapshot = state.publishedSnapshot;
  const timeline = getNowAndUpcoming({
    snapshot,
    nowUtc: new Date().toISOString(),
    audienceGroups: ["all_attendees", "founders"]
  });
  const missingLocationCount = snapshot.scheduleItems.filter((item) => item.locationName.trim().length === 0).length;
  const needsReviewCount = state.draftSessions.filter((session) => session.status === "Needs review").length;

  return NextResponse.json(
    {
      aiSystem: "CURRENT_STATE_AI",
      readOnly: true,
      question,
      answer:
        snapshot.scheduleItems.length === 0
          ? "No approved schedule records are currently published in the canonical snapshot. The staff portal can create drafts, but attendees should not see draft data until a revision is published."
          : `Published revision ${snapshot.revision} has ${timeline.current.length} current session(s), ${timeline.upcoming.length} upcoming session(s), ${state.notificationJobs.length} notification job(s), and ${needsReviewCount} draft session(s) still needing review.`,
      structuredFacts: {
        eventId: snapshot.event.id,
        revision: snapshot.revision,
        draftSessions: state.draftSessions.length,
        scheduleItems: snapshot.scheduleItems.length,
        currentItems: timeline.current.length,
        upcomingItems: timeline.upcoming.length,
        missingLocationCount,
        needsReviewCount,
        attendeeDevices: state.attendeeDevices,
        notificationJobs: state.notificationJobs.length,
        lastPublishedAt: state.lastPublishedAt
      }
    },
    {
      headers: {
        "Cache-Control": "no-store"
      }
    }
  );
}
