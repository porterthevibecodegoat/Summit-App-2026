import { publicAppConfig } from "@not-alone/config";
import { getLiveOpsState } from "../../lib/live-ops-repository";
import { ScheduleWorkbench } from "./schedule-workbench";

export const dynamic = "force-dynamic";

export default async function SchedulePage() {
  const state = await getLiveOpsState();

  return (
    <main className="shell">
      <nav className="nav" aria-label="Staff portal">
        <div className="brand">{publicAppConfig.appName}</div>
        <a href="/">Overview</a>
        <a className="active" href="/schedule">Schedule</a>
        <span>Ask AI</span>
        <span>Make Changes</span>
        <span>Import</span>
        <a href="/notifications">Notifications</a>
        <span>Emergency</span>
        <a href="/history">History</a>
        <span>Settings</span>
      </nav>
      <ScheduleWorkbench snapshot={state.publishedSnapshot} environmentName={publicAppConfig.environmentName} />
    </main>
  );
}
