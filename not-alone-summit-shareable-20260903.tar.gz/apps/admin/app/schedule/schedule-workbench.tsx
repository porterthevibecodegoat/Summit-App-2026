"use client";

import { useEffect, useMemo, useState, type DragEvent } from "react";
import type { EventSnapshot } from "@not-alone/validation";

type DraftSession = {
  id: string;
  day: string;
  start: string;
  end: string;
  title: string;
  speaker: string;
  location: string;
  audience: string;
  status: "Draft" | "Ready" | "Needs review";
  reminders: string;
};

type Proposal = {
  summary: string;
  confidence: "High" | "Medium" | "Low";
  changes: Array<{ id: string; label: string; before: string; after: string }>;
};

type PublishState = {
  revision: number;
  message: string;
  updatedAt: string;
};

type LiveOpsState = {
  mode: "local-adapter" | "supabase";
  revision: number;
  draftSessions: DraftSession[];
  publishedRevision: number;
  lastPublishedAt?: string;
  lastPublishedMessage?: string;
  notificationJobsCount: number;
  attendeeDevices: number;
};

const fallbackDraftSessions: DraftSession[] = [
  {
    id: "draft-wozniak-keynote",
    day: "Mon Nov 2",
    start: "3:00 PM",
    end: "4:00 PM",
    title: "Innovation, Humanity, and Not Being Alone",
    speaker: "Steve Wozniak",
    location: "Encore Theater",
    audience: "All attendees",
    status: "Draft",
    reminders: "30m, 10m"
  },
  {
    id: "draft-reset-lounge",
    day: "Mon Nov 2",
    start: "4:20 PM",
    end: "4:50 PM",
    title: "Guided Reset and Reflection",
    speaker: "Wellness Team",
    location: "Reflection Lounge",
    audience: "All attendees",
    status: "Needs review",
    reminders: "10m"
  },
  {
    id: "draft-founder-reception",
    day: "Mon Nov 2",
    start: "6:00 PM",
    end: "7:30 PM",
    title: "Founder Circle Reception",
    speaker: "Host Committee",
    location: "Terrace Salon",
    audience: "Founders only",
    status: "Draft",
    reminders: "30m"
  }
];

export function ScheduleWorkbench({
  snapshot,
  environmentName
}: {
  snapshot: EventSnapshot;
  environmentName: string;
}) {
  const importedSessions = useMemo<DraftSession[]>(
    () =>
      snapshot.scheduleItems.map((item) => ({
        id: item.id,
        day: `Day ${item.dayOrder + 1}`,
        start: new Intl.DateTimeFormat("en-US", {
          hour: "numeric",
          minute: "2-digit",
          timeZone: snapshot.event.timeZone
        }).format(new Date(item.startUtc)),
        end: new Intl.DateTimeFormat("en-US", {
          hour: "numeric",
          minute: "2-digit",
          timeZone: snapshot.event.timeZone
        }).format(new Date(item.endUtc)),
        title: item.title,
        speaker: item.speakerIds.length > 0 ? `${item.speakerIds.length} linked speaker(s)` : "Unassigned",
        location: item.locationName,
        audience: item.visibilityScope.label,
        status: item.published ? "Ready" : "Draft",
        reminders: `${item.notificationOffsetsMinutes.join("m, ")}m`
      })),
    [snapshot]
  );
  const [sessions, setSessions] = useState<DraftSession[]>(importedSessions.length > 0 ? importedSessions : fallbackDraftSessions);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [stateQuestion, setStateQuestion] = useState("What is live, what is ready, and what still needs review?");
  const [stateAnswer, setStateAnswer] = useState<string | null>(null);
  const [command, setCommand] = useState("The 3pm speaker has now changed to 3:30 and it is now Mike Tyson instead of Steve Wozniak.");
  const [proposal, setProposal] = useState<Proposal | null>(null);
  const [importMessage, setImportMessage] = useState("Drop TXT, CSV, or PDF schedule files here. Text-based files can be parsed now; PDF extraction is queued for the backend parser.");
  const [publishState, setPublishState] = useState<PublishState | null>(null);
  const [apiStatus, setApiStatus] = useState("Loading local live-ops adapter...");
  const [backendMode, setBackendMode] = useState<LiveOpsState["mode"]>("local-adapter");
  const [draftDirty, setDraftDirty] = useState(false);
  const [notifyAttendees, setNotifyAttendees] = useState(false);
  const [publishConfirmed, setPublishConfirmed] = useState(false);
  const readyCount = sessions.filter((session) => session.status === "Ready").length;
  const reminderCount = sessions.filter((session) => session.reminders.trim().length > 0).length;
  const needsReviewCount = sessions.filter((session) => session.status === "Needs review").length;
  const publishIssues = getPublishIssues(sessions);
  const canPublish = publishIssues.length === 0 && publishConfirmed;

  useEffect(() => {
    let mounted = true;

    async function loadLiveOpsState() {
      try {
        const response = await fetch("/api/live-ops/state", { cache: "no-store" });
        if (!response.ok) {
          throw new Error(`Live-ops state returned ${response.status}`);
        }
        const state = (await response.json()) as LiveOpsState;
        if (!mounted) {
          return;
        }
        if (state.draftSessions.length > 0) {
          setSessions(state.draftSessions);
        }
        setBackendMode(state.mode);
        if (state.lastPublishedAt && state.lastPublishedMessage) {
          setPublishState({
            revision: state.publishedRevision,
            message: state.lastPublishedMessage,
            updatedAt: new Date(state.lastPublishedAt).toLocaleString()
          });
        }
        setApiStatus(
          `Connected to ${state.mode}. Published revision ${state.publishedRevision}; ${state.notificationJobsCount} notification job(s); ${state.attendeeDevices} registered device(s).`
        );
      } catch (error) {
        if (mounted) {
          setApiStatus(
            error instanceof Error
              ? `Local adapter unavailable: ${error.message}`
              : "Local adapter unavailable. Drafts remain browser-local until the API responds."
          );
        }
      }
    }

    void loadLiveOpsState();

    return () => {
      mounted = false;
    };
  }, []);

  function moveSession(targetId: string) {
    if (!draggedId || draggedId === targetId) {
      return;
    }

    setSessions((current) => {
      const dragged = current.find((item) => item.id === draggedId);
      if (!dragged) {
        return current;
      }

      const remaining = current.filter((item) => item.id !== draggedId);
      const targetIndex = remaining.findIndex((item) => item.id === targetId);
      const next = [...remaining];
      next.splice(targetIndex, 0, dragged);
      return next;
    });
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  function updateSession(id: string, field: keyof DraftSession, value: string) {
    setSessions((current) =>
      current.map((session) => (session.id === id ? { ...session, [field]: value, status: "Needs review" } : session))
    );
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  function markSessionStatus(id: string, status: DraftSession["status"]) {
    setSessions((current) => current.map((session) => (session.id === id ? { ...session, status } : session)));
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  function addSession(afterId?: string) {
    setSessions((current) => {
      const nextSession = createBlankSession(current.length);
      if (!afterId) {
        return [...current, nextSession];
      }

      const insertAfter = current.findIndex((session) => session.id === afterId);
      if (insertAfter < 0) {
        return [...current, nextSession];
      }

      const next = [...current];
      next.splice(insertAfter + 1, 0, nextSession);
      return next;
    });
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  function duplicateSession(id: string) {
    setSessions((current) => {
      const source = current.find((session) => session.id === id);
      if (!source) {
        return current;
      }

      const sourceIndex = current.findIndex((session) => session.id === id);
      const copy = {
        ...source,
        id: createDraftId("copy"),
        title: `${source.title} Copy`,
        status: "Needs review" as const
      };
      const next = [...current];
      next.splice(sourceIndex + 1, 0, copy);
      return next;
    });
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  function deleteSession(id: string) {
    setSessions((current) => current.filter((session) => session.id !== id));
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  function runCommand() {
    setProposal(createScheduleProposal(command, sessions));
  }

  async function askStateAi() {
    try {
      const response = await fetch("/api/ai/state", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: stateQuestion })
      });
      const result = (await response.json()) as { answer?: string };
      if (!response.ok || !result.answer) {
        throw new Error(`State AI returned ${response.status}`);
      }
      setStateAnswer(result.answer);
    } catch {
      setStateAnswer(createStateAnswer(stateQuestion, sessions, snapshot.revision, publishState));
    }
  }

  async function saveDraft() {
    setApiStatus("Saving draft to local live-ops adapter...");
    try {
      const response = await fetch("/api/live-ops/draft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessions })
      });
      const result = (await response.json()) as { ok?: boolean; message?: string; error?: string; draftSessions?: DraftSession[] };
      if (!response.ok || !result.ok) {
        throw new Error(result.error ?? `Draft save returned ${response.status}`);
      }
      if (result.draftSessions) {
        setSessions(result.draftSessions);
      }
      setDraftDirty(false);
      setApiStatus(result.message ?? "Draft saved.");
    } catch (error) {
      setApiStatus(error instanceof Error ? error.message : "Draft save failed.");
    }
  }

  function applyProposal() {
    if (!proposal) {
      return;
    }

    setSessions((current) =>
      current.map((session) => {
        const sessionChanges = proposal.changes.filter((change) => change.id === session.id);
        if (sessionChanges.length === 0) {
          return session;
        }

        return sessionChanges.reduce<DraftSession>((draft, change) => {
          if (change.label === "Start time") {
            return { ...draft, start: change.after, status: "Needs review" };
          }

          if (change.label === "Speaker") {
            return { ...draft, speaker: change.after, status: "Needs review" };
          }

          return draft;
        }, session);
      })
    );
    setProposal(null);
    setDraftDirty(true);
    setPublishConfirmed(false);
  }

  async function publishGlobally() {
    if (!canPublish) {
      return;
    }

    setApiStatus("Publishing reviewed draft revision...");
    try {
      const response = await fetch("/api/live-ops/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessions, source: "MANUAL_EDITOR", notifyAttendees, confirmPublish: publishConfirmed })
      });
      const result = (await response.json()) as {
        ok?: boolean;
        revision?: number;
        lastPublishedAt?: string;
        message?: string;
        error?: string;
        issues?: string[];
        notificationJobsCount?: number;
      };

      if (!response.ok || !result.ok || !result.revision) {
        throw new Error(result.issues?.join(" ") ?? result.error ?? `Publish returned ${response.status}`);
      }

      setPublishState({
        revision: result.revision,
        message:
          result.message ??
          "Published revision to the local attendee snapshot. Production delivery will use Supabase realtime and server push workers.",
        updatedAt: result.lastPublishedAt ? new Date(result.lastPublishedAt).toLocaleString() : new Date().toLocaleString()
      });
      setDraftDirty(false);
      setPublishConfirmed(false);
      setApiStatus(`Published revision ${result.revision}; ${result.notificationJobsCount ?? 0} notification job(s) reconciled.`);
    } catch (error) {
      setApiStatus(error instanceof Error ? error.message : "Publish failed.");
    }
  }

  function handleDragOver(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
  }

  function handleDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    const file = event.dataTransfer.files[0];

    if (!file) {
      return;
    }

    if (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")) {
      setImportMessage(`${file.name} received. Production PDF parsing needs the backend parser before it can publish attendee data.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const text = String(reader.result ?? "");
      const response = await fetch("/api/import/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileName: file.name, text })
      });
      const result = (await response.json()) as { ok?: boolean; message?: string; sessions?: DraftSession[]; error?: string };
      const parsed = result.sessions ?? [];
      if (!response.ok || !result.ok || parsed.length === 0) {
        setImportMessage(result.message ?? result.error ?? `${file.name} loaded, but no schedule rows matched the current parser.`);
        return;
      }

      setSessions(parsed);
      setDraftDirty(true);
      setPublishConfirmed(false);
      setImportMessage(result.message ?? `${file.name} imported into draft review with ${parsed.length} parsed session(s).`);
    };
    reader.readAsText(file);
  }

  return (
    <section className="content controlRoom">
      <div className="pageHeader">
        <div>
          <div className="kicker">Schedule Control Room - {environmentName}</div>
          <h1>Build, review, and publish attendee programming</h1>
          <p className="headerCopy">
            Drag sessions into order, use the AI command bar for structured edits, and stage import files before they
            become attendee-facing data.
          </p>
        </div>
        <div className="environmentBadge">{backendMode}</div>
      </div>

      <div className="systemNotice">{apiStatus}</div>

      <div className="metricGrid controlMetrics">
        <Metric label="Draft sessions" value={String(sessions.length)} />
        <Metric label="Ready to publish" value={String(readyCount)} />
        <Metric label="Needs review" value={String(needsReviewCount)} />
        <Metric label="Reminder metadata" value={String(reminderCount)} />
      </div>

      {publishIssues.length > 0 ? (
        <div className="systemNotice warningNotice">
          <strong>Publish review needed:</strong> {publishIssues.join(" ")}
        </div>
      ) : (
        <div className="systemNotice successNotice">
          All draft rows have the minimum fields needed for attendee-safe publication.
        </div>
      )}

      <div className="assistantGrid">
        <section className="panel assistantPanel stateAiPanel">
          <div className="panelHeader">
            <div>
              <div className="label">State AI</div>
              <h2>Ask what is true right now</h2>
            </div>
            <span className="badge mutedBadge">Read only</span>
          </div>
          <div className="commandGrid">
            <textarea
              aria-label="State AI question"
              value={stateQuestion}
              onChange={(event) => setStateQuestion(event.target.value)}
              placeholder="Ask about current draft state, reminders, audience rules, or what still needs review."
            />
            <button className="button" type="button" onClick={askStateAi}>Ask State AI</button>
          </div>
          {stateAnswer ? (
            <div className="answerBox">
              <div className="label">Current-state answer</div>
              <p>{stateAnswer}</p>
            </div>
          ) : null}
        </section>

        <section className="panel assistantPanel commandPanel">
          <div className="panelHeader">
            <div>
              <div className="label">Official Change AI</div>
              <h2>Make reviewed changes for the app</h2>
            </div>
            <span className="badge mutedBadge">Proposal required</span>
          </div>
          <div className="commandGrid">
            <textarea
              aria-label="Official Change AI command"
              value={command}
              onChange={(event) => setCommand(event.target.value)}
              placeholder="Example: Move the 3pm keynote to 3:30 and change the speaker to Mike Tyson."
            />
            <button className="button" type="button" onClick={runCommand}>Generate Proposal</button>
          </div>
          {proposal ? (
            <div className="proposalBox">
              <div>
                <div className="label">Proposed update - {proposal.confidence} confidence</div>
                <h3>{proposal.summary}</h3>
              </div>
              <div className="changeList">
                {proposal.changes.map((change) => (
                  <div className="changeRow" key={`${change.id}-${change.label}`}>
                    <span>{change.label}</span>
                    <strong>{change.before}</strong>
                    <span>-&gt;</span>
                    <strong>{change.after}</strong>
                  </div>
                ))}
              </div>
              <div className="proposalActions">
                <button className="button" type="button" onClick={applyProposal}>Apply to Draft</button>
                <button className="ghostButton" type="button" onClick={() => setProposal(null)}>Dismiss</button>
              </div>
            </div>
          ) : null}
        </section>
      </div>

      <div className="workbenchGrid">
        <section className="panel scheduleBoard">
          <div className="panelHeader">
            <div>
              <div className="label">Drag-and-drop agenda</div>
              <h2>Draft schedule</h2>
            </div>
            <div className="panelActions">
              <button className="ghostButton" type="button" onClick={() => addSession()}>
                Add Session
              </button>
              <button
                className="ghostButton"
                type="button"
                onClick={() => {
                  setSessions((current) => current.map((session) => ({ ...session, status: "Ready" })));
                  setDraftDirty(true);
                  setPublishConfirmed(false);
                }}
              >
                Mark All Ready
              </button>
              <button className="ghostButton" type="button" onClick={saveDraft}>
                Save Draft
              </button>
            </div>
          </div>

          <div className="sessionList">
            {sessions.map((session) => (
              <article
                className={`sessionCard ${draggedId === session.id ? "dragging" : ""}`}
                draggable
                key={session.id}
                onDragStart={() => setDraggedId(session.id)}
                onDragEnd={() => setDraggedId(null)}
                onDragOver={handleDragOver}
                onDrop={() => moveSession(session.id)}
              >
                <div className="dragHandle" aria-hidden="true">::</div>
                <div className="sessionFields">
                  <div className="sessionTopline">
                    <input value={session.day} onChange={(event) => updateSession(session.id, "day", event.target.value)} aria-label="Day" />
                    <input value={session.start} onChange={(event) => updateSession(session.id, "start", event.target.value)} aria-label="Start time" />
                    <input value={session.end} onChange={(event) => updateSession(session.id, "end", event.target.value)} aria-label="End time" />
                  </div>
                  <input className="titleInput" value={session.title} onChange={(event) => updateSession(session.id, "title", event.target.value)} aria-label="Title" />
                  <div className="sessionMetaGrid">
                    <input value={session.speaker} onChange={(event) => updateSession(session.id, "speaker", event.target.value)} aria-label="Speaker" />
                    <input value={session.location} onChange={(event) => updateSession(session.id, "location", event.target.value)} aria-label="Location" />
                    <select value={session.audience} onChange={(event) => updateSession(session.id, "audience", event.target.value)} aria-label="Audience">
                      <option>All attendees</option>
                      <option>Founders only</option>
                      <option>Staff only</option>
                      <option>VIP</option>
                    </select>
                    <input value={session.reminders} onChange={(event) => updateSession(session.id, "reminders", event.target.value)} aria-label="Reminder offsets" />
                  </div>
                </div>
                <div className="sessionActions">
                  <span className={`statusPill ${session.status === "Ready" ? "ready" : ""}`}>{session.status}</span>
                  <button className="miniButton" type="button" onClick={() => markSessionStatus(session.id, "Ready")}>
                    Ready
                  </button>
                  <button className="miniButton" type="button" onClick={() => markSessionStatus(session.id, "Needs review")}>
                    Review
                  </button>
                  <button className="miniButton" type="button" onClick={() => addSession(session.id)}>
                    Add Below
                  </button>
                  <button className="miniButton" type="button" onClick={() => duplicateSession(session.id)}>
                    Duplicate
                  </button>
                  <button className="miniButton dangerMiniButton" type="button" onClick={() => deleteSession(session.id)}>
                    Delete
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <aside className="sideStack">
          <section className="panel importPanel" onDragOver={handleDragOver} onDrop={handleDrop}>
            <div className="label">Schedule import</div>
            <h2>Drop updated agenda files</h2>
            <p>{importMessage}</p>
            <div className="dropZone">
              <strong>Drop PDF, TXT, or CSV</strong>
              <span>Imported rows stay draft until reviewed.</span>
            </div>
          </section>

          <section className="panel publishPanel">
            <div className="label">Attendee app publishing</div>
            <h2>Controlled rollout path</h2>
            <ol className="publishSteps">
              <li>Staff edits draft agenda.</li>
              <li>AI/import changes become reviewable proposals.</li>
              <li>Authorized staff publishes a snapshot revision.</li>
              <li>Mobile app refreshes the published schedule from /api/snapshot.</li>
              <li>Notification jobs are recalculated for the future server worker.</li>
            </ol>
            <div className="publishControls">
              <label className="checkRow">
                <input
                  checked={notifyAttendees}
                  onChange={(event) => setNotifyAttendees(event.target.checked)}
                  type="checkbox"
                />
                <span>Queue notification jobs for this revision</span>
              </label>
              <label className="checkRow">
                <input
                  checked={publishConfirmed}
                  onChange={(event) => setPublishConfirmed(event.target.checked)}
                  type="checkbox"
                />
                <span>I reviewed this draft and want it attendee-facing</span>
              </label>
            </div>
            {publishState ? (
              <div className="publishResult">
                <div className="label">Published revision {publishState.revision}</div>
                <p>{publishState.message}</p>
                <span>{publishState.updatedAt}</span>
              </div>
            ) : null}
            <button
              className={canPublish ? "button fullWidthButton" : "disabledButton"}
              disabled={!canPublish}
              type="button"
              onClick={publishGlobally}
            >
              {publishIssues.length > 0
                ? "Resolve review items before publish"
                : publishConfirmed
                  ? "Publish Attendee Snapshot"
                  : "Confirm reviewed draft before publish"}
            </button>
            {draftDirty ? <p className="tinyNote">Unsaved draft changes are present.</p> : null}
          </section>
        </aside>
      </div>
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="metric">
      <div className="label">{label}</div>
      <div className="value">{value}</div>
    </div>
  );
}

function getPublishIssues(sessions: DraftSession[]) {
  const issues: string[] = [];

  if (sessions.length === 0) {
    return ["Add at least one session."];
  }

  const notReadyCount = sessions.filter((session) => session.status !== "Ready").length;
  const missingTitleCount = sessions.filter((session) => session.title.trim().length === 0).length;
  const missingLocationCount = sessions.filter((session) => !isRealLocation(session.location)).length;
  const invalidTimeCount = sessions.filter((session) => !isValidTime(session.start) || !isValidTime(session.end)).length;

  if (notReadyCount > 0) {
    issues.push(`${notReadyCount} row(s) are not marked Ready.`);
  }
  if (missingTitleCount > 0) {
    issues.push(`${missingTitleCount} row(s) are missing titles.`);
  }
  if (missingLocationCount > 0) {
    issues.push(`${missingLocationCount} row(s) are missing locations.`);
  }
  if (invalidTimeCount > 0) {
    issues.push(`${invalidTimeCount} row(s) need valid start/end times.`);
  }

  return issues;
}

function isValidTime(value: string) {
  return /^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)$/i.test(value.trim());
}

function isRealLocation(value: string) {
  const normalized = value.trim().toLowerCase();
  return normalized.length > 0 && normalized !== "needs location";
}

function createBlankSession(index: number): DraftSession {
  return {
    id: createDraftId("new"),
    day: "Mon Nov 2",
    start: "9:00 AM",
    end: "9:45 AM",
    title: `New Session ${index + 1}`,
    speaker: "Unassigned",
    location: "Needs location",
    audience: "All attendees",
    status: "Needs review",
    reminders: "10m"
  };
}

function createDraftId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.round(Math.random() * 10000)}`;
}

function createScheduleProposal(command: string, sessions: DraftSession[]): Proposal {
  const normalized = command.toLowerCase();
  const targetTime = normalized.match(/\b(\d{1,2})(?::00)?\s*(am|pm)\b/)?.[0] ?? "";
  const target = sessions.find((session) => session.start.toLowerCase().replace(":00", "").includes(targetTime.replace(":00", ""))) ?? sessions[0];

  if (!target) {
    return {
      summary: "No matching session was found.",
      confidence: "Low",
      changes: []
    };
  }

  const changes: Proposal["changes"] = [];
  const newTime = normalized.match(/(?:changed to|move(?:d)? to|to)\s+(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)/)?.[1];
  const speakerMatch = command.match(/(?:it is now|now|speaker is now)\s+([A-Z][A-Za-z.'-]*(?:\s+[A-Z][A-Za-z.'-]*){0,3})(?:\s+instead of|\.)/);

  if (newTime) {
    changes.push({
      id: target.id,
      label: "Start time",
      before: target.start,
      after: formatCommandTime(newTime, target.start)
    });
  }

  if (speakerMatch?.[1]) {
    changes.push({
      id: target.id,
      label: "Speaker",
      before: target.speaker,
      after: speakerMatch[1]
    });
  }

  return {
    summary: changes.length > 0 ? `Update ${target.title}` : `I found ${target.title}, but need a clearer time or speaker change.`,
    confidence: changes.length > 1 ? "High" : changes.length === 1 ? "Medium" : "Low",
    changes
  };
}

function createStateAnswer(
  question: string,
  sessions: DraftSession[],
  baseRevision: number,
  publishState: PublishState | null
) {
  const ready = sessions.filter((session) => session.status === "Ready");
  const review = sessions.filter((session) => session.status === "Needs review");
  const firstLiveCandidate = sessions[0];
  const notificationReady = sessions.filter((session) => session.reminders.trim().length > 0);
  const latestRevision = publishState?.revision ?? baseRevision;
  const intent = question.trim().length > 0 ? question.trim() : "current state";

  return [
    `For "${intent}", the portal currently has ${sessions.length} draft session(s), ${ready.length} ready to publish, and ${review.length} needing review.`,
    firstLiveCandidate ? `The first attendee-facing candidate is ${firstLiveCandidate.title} at ${firstLiveCandidate.start} with ${firstLiveCandidate.speaker}.` : "There is no attendee-facing candidate yet.",
    `${notificationReady.length} session(s) include reminder metadata.`,
    `Latest staged/published revision shown in this portal is ${latestRevision}.`,
    "Production State AI will be read-only and grounded in Supabase drafts, published snapshots, notification jobs, audit logs, and attendee sync health."
  ].join(" ");
}

function formatCommandTime(value: string, fallback: string) {
  const trimmed = value.trim().toUpperCase();
  if (trimmed.includes("AM") || trimmed.includes("PM")) {
    return normalizeTime(trimmed);
  }

  const meridiem = fallback.toUpperCase().includes("AM") ? "AM" : "PM";
  return normalizeTime(`${trimmed} ${meridiem}`);
}

function normalizeTime(value: string) {
  const match = value.match(/^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)$/i);
  const hour = match?.[1];
  const minute = match?.[2] ?? "00";
  const meridiem = match?.[3];

  if (!hour || !meridiem) {
    return value;
  }

  return `${hour}:${minute} ${meridiem.toUpperCase()}`;
}
