import type { StaffDraftSession } from "./live-ops-store";

export function parseScheduleText(text: string): StaffDraftSession[] {
  const parsed: StaffDraftSession[] = [];

  text.split(/\r?\n/).forEach((line, index) => {
    const normalizedLine = line.replace(/\u2013/g, "-");
    const match = normalizedLine.match(/(\d{1,2}(?::\d{2})?\s*(?:AM|PM))\s*-\s*(\d{1,2}(?::\d{2})?\s*(?:AM|PM))\s+(.+)/i);
    const start = match?.[1];
    const end = match?.[2];
    const body = match?.[3];

    if (!start || !end || !body) {
      return;
    }

    const [rawTitle, rawSpeaker] = body.split(/\s+-\s+/);
    const title = rawTitle?.trim();

    if (!title) {
      return;
    }

    parsed.push({
      id: `imported-${index}-${Date.now()}`,
      day: "Imported",
      start: normalizeTime(start),
      end: normalizeTime(end),
      title,
      speaker: rawSpeaker?.trim() || "Unassigned",
      location: "Needs location",
      audience: "All attendees",
      status: "Needs review",
      reminders: "10m"
    });
  });

  return parsed;
}

function normalizeTime(value: string) {
  const match = value.match(/^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)$/i);
  const hour = match?.[1];
  const minute = match?.[2] ?? "00";
  const meridiem = match?.[3];

  if (!hour || !meridiem) {
    return value;
  }

  return `${hour}:${minute} ${meridiem.toUpperCase()}`;
}
