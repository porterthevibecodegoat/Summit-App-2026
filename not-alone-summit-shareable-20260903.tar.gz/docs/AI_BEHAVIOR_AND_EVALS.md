# AI Behavior And Evals

AI is disabled by default and no model is hardcoded.

Required behavior for future implementation:

- Attendee AI reads only approved published schedule, location, announcement, FAQ, and ICF content.
- Staff AI creates strict proposals only and never publishes from free text.
- OpenAI Responses API calls happen server-side with `store: false` by default.
- Structured outputs are validated before rendering or execution.
- Evaluation fixtures must cover typos, role restrictions, unpublished facts, changed/canceled events, prompt injection, and ambiguous admin commands.
