# Roadmap To Live App

This is the practical path from the current development build to a fully usable Not Alone Summit attendee app, staff control portal, and App Store-ready release.

## Current Foundation

- The repo is a true monorepo with `apps/mobile`, `apps/admin`, shared typed packages, and Supabase migrations.
- The attendee app runs as a native Expo development build and reads the same validated event snapshot model as the staff portal.
- The staff portal has a local live-ops adapter, drag-and-drop schedule workbench, State AI preview, Official Change AI proposal workflow, import staging, publish confirmation, notification job visibility, and activity history.
- The shared demo snapshot export is schema-validated before the mobile app consumes it.
- Supabase-ready server code exists for drafts, revisions, audit records, attendee device registrations, and notification jobs.

## Next Product Milestones

1. Connect staging Supabase.
   - Create the Supabase project.
   - Run migrations in `supabase/migrations`.
   - Configure Auth, staff roles, and RLS tests.
   - Set server-only environment variables for the staff portal.

2. Finish production staff operations.
   - Replace local role fallback with real staff sign-in.
   - Add import job history for uploaded PDFs and spreadsheets.
   - Add approval/rejection workflow for AI-generated proposals.
   - Add publish diff preview showing what attendees will see before the change goes live.
   - Add rollback to the last known good published revision.

3. Finish app-wide sync.
   - Point the mobile app at the deployed snapshot API.
   - Add realtime or interval refresh for published revisions.
   - Keep offline cache fallback for schedule, map, help, and event info.
   - Show a quiet “updated” state when the app receives a new revision.

4. Finish push notifications.
   - Configure EAS project ID and Apple push credentials.
   - Enable attendee device registration only in production/staging builds.
   - Build the server-side notification dispatch worker.
   - Add delivery logs, retry status, and cancel/reschedule behavior.
   - Test notifications on real devices before App Store submission.

5. Finish real AI.
   - Add server-side OpenAI credentials.
   - Ground State AI in published snapshots, drafts, audit logs, notification jobs, and import jobs.
   - Ground Official Change AI in the same data, but require staff review before mutation.
   - Add evals for schedule edits, time changes, speaker swaps, audience changes, and notification safety.

6. Professionalize final attendee UX.
   - Replace all placeholder event facts with approved content.
   - Add final speaker images, venue maps, FAQ/help copy, sponsor/partner copy, and accessibility review.
   - Tune iPhone layouts across current small, standard, Pro, and Pro Max devices.
   - Complete a no-warning native simulator pass and real-device TestFlight pass.

7. Prepare App Store release.
   - Replace app icon and splash assets.
   - Add privacy policy, support URL, data inventory, and reviewer notes.
   - Configure EAS production build profiles.
   - Submit to TestFlight first, then App Review after stakeholder sign-off.

## Definition Of Done

- Staff can safely update schedule, speakers, locations, visibility, event info, map data, and notifications from the portal.
- Published changes update every attendee app through the canonical published snapshot.
- Push notifications are sent only by the server worker and are tied to published revision IDs.
- AI can explain current state and propose official changes, but cannot bypass staff review, audit logs, or publish confirmation.
- The iOS app works offline for essential event information and refreshes cleanly when connectivity returns.
- The release has zero known P0/P1 defects, passes required checks, and has native iPhone evidence before App Store submission.
