# Offline Sync

Current foundation:

- Demo snapshot is schema-validated in `packages/test-fixtures`.
- `pnpm snapshot:pull` exports a bundled snapshot to `apps/mobile/assets/demo-snapshot.json`.
- Mobile UI can fetch a published snapshot from `EXPO_PUBLIC_API_BASE_URL` and keeps using the bundled validated fallback if synchronization fails.
- Remote snapshots are parsed through the shared Zod event snapshot schema before becoming active app data.
- The staff portal local adapter publishes attendee-safe snapshots through `GET /api/snapshot`, so Expo web/native development can verify the app reads the same published revision as the portal.

Next production steps:

- Hydrate SQLite from the bundled snapshot on first launch.
- Store incremental sync payloads transactionally.
- Preserve the last valid snapshot when validation or migration fails.
- Track server time and clock offset for reliable "Now" calculations.
- Check for newer published revisions on launch, foreground resume, manual refresh, relevant push notification open, and safe active-use intervals.
- Realtime subscriptions may speed up updates but must not be the only synchronization path.
