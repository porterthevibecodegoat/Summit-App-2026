import { eventSnapshotSchema, type EventSnapshot } from "@not-alone/validation";

export const demoSnapshot: EventSnapshot = eventSnapshotSchema.parse({
  event: {
    id: "not-alone-summit-2026-demo",
    name: "Not Alone Summit",
    organizationName: "Inspiring Children Foundation",
    timeZone: "America/Los_Angeles",
    dateLabel: "November 2-4, 2026",
    venueName: "Wynn Las Vegas",
    city: "Las Vegas, Nevada",
    positioning: "A premier national convening advancing emotional and mental health through science, lived experience, storytelling, music, and innovation.",
    presentedBy: "Villa Bibbiani",
    poweredBy: "Steven & Alexandra Cohen Foundation",
    tracks: [
      "Panels",
      "Awards",
      "Concerts",
      "Meditation",
      "Workshops",
      "VIP Dinners",
      "Fitness & Yoga",
      "Philanthropy"
    ],
    featuredPeople: [
      {
        name: "Steve Wozniak",
        role: "Co-Founder of Apple & Mental Health Advocate",
        group: "Co-Chair"
      },
      {
        name: "Jewel",
        role: "Singer-Songwriter and Mental Health Pioneer",
        group: "Co-Chair"
      },
      {
        name: "Cherrial Odell",
        role: "Inspiring Children Alumna",
        group: "Co-Chair"
      },
      {
        name: "Jason Kennedy",
        role: "Entertainment Journalist",
        group: "Summit Host"
      },
      {
        name: "Loni Love",
        role: "Comedian & TV Host",
        group: "Awards Host"
      }
    ],
    demo: true
  },
  revision: 1,
  serverTimeUtc: "2026-08-31T18:00:00.000Z",
  locations: [],
  scheduleItems: [],
  contentPages: [
    {
      id: "1442c4b0-46ff-47ab-95a6-f6a155593748",
      slug: "inspiring-children-foundation",
      title: "Inspiring Children Foundation",
      body: "Inspiring Children Foundation supports young people in Las Vegas through programs that connect physical health, emotional wellbeing, academics, athletics, creativity, entrepreneurship, and service.",
      published: true,
      revision: 1
    }
  ]
});
