import { eventSnapshotSchema, type EventSnapshot } from "@not-alone/validation";

export async function fetchPublishedSnapshot(apiBaseUrl: string): Promise<EventSnapshot> {
  const response = await fetch(`${apiBaseUrl}/api/snapshot`);

  if (!response.ok) {
    throw new Error(`Unable to fetch published snapshot: ${response.status}`);
  }

  return eventSnapshotSchema.parse(await response.json());
}
